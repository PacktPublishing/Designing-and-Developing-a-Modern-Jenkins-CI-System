#!/usr/bin/env bash

## Start containers
docker-compose up --build

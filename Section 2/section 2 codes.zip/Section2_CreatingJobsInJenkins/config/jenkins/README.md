Jenkins Groovy Init Mixins
--------------------------

There is a distinct lack of documentation about how to initialize Jenkins from groovy.

An example of how to use this repository is here: https://github.com/visualphoenix/docker-jenkins-demo

Clone this repo as a submodule into your jenkins home and use the example code from the demo repository to
mix in the functions you want to include in your init script.

Maybe this will become a thing you want to contribute fixes/enhancements to.

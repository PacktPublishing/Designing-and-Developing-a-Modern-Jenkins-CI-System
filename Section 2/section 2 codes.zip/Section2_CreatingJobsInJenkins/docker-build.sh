#!/usr/bin/env bash

docker-compose down --rmi all
docker-compose create
